# ReadMe File for Automation script execution for Phase 1

This ReadMe file provides instructions for executing the automation script of iDashboard for Phase 1. The Automation script is designed to test the functionality of the application under different scenarios. The objectives of this project are to automate the test cases, reduce manual effort, and improve the quality of the software.

## Getting Started

To get started with the automation script, follow these steps:

### Installation process

1. Clone the repository to your local machine.
2. HTTPS Link to AzureDevops Repository for cloning ( https://QEAPDPPilotProject@dev.azure.com/QEAPDPPilotProject/CIQD/_git/CIQD )
2. Open the cloned repository in your preferred IDE (Eclipse).
3. Import the Project folder as a Maven Project in the IDE .

### Software dependencies

The automation script requires the following software dependencies:

- Java 11 or higher
- Eclipse IDE
- GIT Bash
- TestNG framework version (7.7.0)
- Selenium WebDriver version (4.14.1)
- Cucumber framework version (7.14.0)

### Latest releases

The latest release of the automation script is v1.0.0. You can find it in the Releases section of the repository.

## Build and Test

To build and test the automation script, follow these steps:

### Changes to be made in Global Properties file

Make the following changes in the Global Properties file:

1. Update the `Global Settings.properties` file with the appropriate values for the Below given inputs, if these details are not changed then errors can occure due to existing details and script can fail.

NOTE:- Please use the unique entry for each detail you are filling before running the script in global settings.properties file and only change the input for the stated values others must not be changed in order to make the script run successfully.

	* ApplicationUrl should be checked (http://10.120.101.32:8089/ciqdashboard)
	* User Registration Data such as (FirstName, LastName, EmailId, RegPassword, confirmPassword)
	* Normal-User Login Details should be filled as per the user (userName,Password) should be changed.
	* Project Management Data should be changed (OrgName, OrgDescription, LobName, LobDescription, prjName, prjDescription, srcTool) these details should be changed to let check the proper creation Automation Script.
	*Dashboard Creation Details need to be changed before running the script (Roll_Name,Description,TMPName,DashboardName,dashboardName)

### Changes to be made in XML File for execution

Make the following changes in the XML file for execution:

NOTE: Do not try to change other inputs or parameters.

1. Update the `Test_WEB.xml` file with the appropriate values for the Environment and Browser.
2. Currently we have the Local Script execution so in ExecutionMode value is LOCAL and in BrowserName value can be EGDE,CHROME etc.

### Changes to be made in Runner file for running the specific execution

Make the following changes in the Runner file for running the specific execution:

1. Update the `RunnerWebApp.java` file with the appropriate values for the test cases.
2. We have given certain Tags to our Testcases sand Scenarios depending upon the flow which are stated below.
	* @EndToEnd :- for all the 46 testcases
	* @Regression :- for all the positive testcases
these are the common Tags and if you want to check the single functionalty or Perticular Page we have seperate tags for them as well on there perticular feature file.
3. If wanted to Run Particular page or Particular Scenario can copy the tag from particular feature file and paste it in RunnerWebApp.xml file in @tag and then RUN the script.

### Report to be Checked after successful execution of automation script

After successful execution of the automation script, check the report for the following:

1. Verify that all the test cases have passed in console or if error  is there, then can be checked there itself.
2. Check the Reports files for any errors or warnings which can be found in project folder in test-output Folder.
3. Check the screenshots for any issues which are in Results Folder in project itself.
