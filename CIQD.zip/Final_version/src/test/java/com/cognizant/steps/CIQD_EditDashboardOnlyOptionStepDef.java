//Developed By Rohan Yerva and refactored by Rohit Bhavad

package com.cognizant.steps;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;

import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_EditDashboardOnlyOptionsPage;
import com.cognizant.pages.CIQD_LoginPage;
import com.cognizant.pages.CIQD_NewChartsCreationPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CIQD_EditDashboardOnlyOptionStepDef extends MasterSteps {

	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());

	String userName = properties.getProperty("UserName");
	String password = properties.getProperty("Password");
	String projectName = properties.getProperty("ProjectName");
    String chartTitle = properties.getProperty("ChartTitle");

	CIQD_EditDashboardOnlyOptionsPage editDashboardOptions;
	CIQD_NewChartsCreationPage newChartCreation;
	CIQD_LoginPage loginPage;

	
	public CIQD_EditDashboardOnlyOptionStepDef() {
		editDashboardOptions = new CIQD_EditDashboardOnlyOptionsPage(driver);
		newChartCreation = new CIQD_NewChartsCreationPage(driver);
		loginPage = new CIQD_LoginPage(driver);
	}
	
	@Given("user navigates to the Project Tab")
	public void user_navigates_to_the_project_tab() {
		editDashboardOptions.navigateToProject();
		attachScreenshotForWeb();
	}
	
	//method verifies if the user is able to see the existing dashboard under project tab 
	@Given("Existing dashboard is visible to the user")
	public void existing_dashboard_is_visible_to_the_user() {
		boolean IsExistingDashboardVisible = editDashboardOptions.isExistingDashboardVisible();
		assertTrue(IsExistingDashboardVisible,"User should be able to see existing dashboard");
        if(IsExistingDashboardVisible) {
    	    System.out.println("\n Assertion Passed: User is able to see existing dashboard");
        }
        attachScreenshotForWeb();
	}
	
	//method opens the existing dashboard that is to be edited
	@When("User opens an existing project dashboard")
	public void opens_an_existing_project_dashboard() {
		editDashboardOptions.dropdownExistingDashboardsClick();
		attachScreenshotForWeb();
	}

	//method verifies if the existing dashboard is opened successfully
	@Then("Dashboard should be opened successfully")
	public void dashboard_should_be_opened_successfully() {	
        editDashboardOptions = new CIQD_EditDashboardOnlyOptionsPage(driver);
        editDashboardOptions.isOnDashboardScreen();
		attachScreenshotForWeb();
        assertTrue(editDashboardOptions.isOnDashboardScreen(), "User should be on the dashboard screen");
        if(editDashboardOptions.isOnDashboardScreen()) {
    	    System.out.println("\n Assertion Passed: User is navigated to the dashboard screen");
        }
    }
	
	//method verifies if edit dashboard screen is displayed
	@Then("Edit Dashboard screen should be displayed")
	public void the_user_is_on_the_edit_dashboard_screen() {		
        editDashboardOptions = new CIQD_EditDashboardOnlyOptionsPage(driver);
        editDashboardOptions.isOnEditDashboardScreen();
		attachScreenshotForWeb();
        assertTrue(editDashboardOptions.isOnEditDashboardScreen(), "User should be on the edit dashboard screen");
        if(editDashboardOptions.isOnEditDashboardScreen()) {
    	    System.out.println("\n Assertion Passed: User is navigated to the edit dashboard screen");
        }
    }
	
	//method selects the chart to be edited (only options)
	@When("The user selects the chart with title to edit")
	public void the_user_selects_the_chart_to_edit() {
	    // Attempt to select the chart
	    boolean chartSelected = editDashboardOptions.selectChartToEdit(chartTitle);
	    editDashboardOptions.selectChartToEdit(chartTitle);
	    // Now, assert that the chart is selected in edit mode
	    assertTrue(chartSelected, "Chart should be selected for editing");
	    System.out.println("\n Assertion Passed: User is able to select the respective chart");
	    attachScreenshotForWeb();
	}

	//method verifies if the chart is selected and is in edit mode
	@Then("The selected chart with title should be in edit mode")
	public void the_selected_chart_with_title_should_be_in_edit_mode() {
	    // Attempt to verify if the respective chart is selected
	    boolean verifyChartSelected = editDashboardOptions.isChartSelected(chartTitle);
	    // Now, assert to verify that the chart is selected in edit mode
	    assertTrue(verifyChartSelected, "Chart should be selected for editing");
		attachScreenshotForWeb();
	    System.out.println("\n Assertion Passed: Respective chart is selected in edit mode successfully");
	}
	
	
	//method modifies the Card options with the parameters provided in the feature file
	@When("the user modifies the Title,  InnerPadding {string}, CardColor {string}, TextColor {string} and Caption {string}")
	public void the_user_modifies_the_title_caption_subcaption_x_axis_and_y_axis_names(String iPadding, String cColor, String tColor, String cCaption) {
        editDashboardOptions.modifyCardChartOptions(chartTitle, iPadding, cColor, tColor, cCaption);
		attachScreenshotForWeb();
	}
		
	
	//method verifies if the card options are modified/edited successfully
	@Then("Chart options Title, InnerPadding {string}, CardColor {string}, TextColor {string} and Caption {string} should be modified successfully")	
	public void chart_options_title_InnerPadding_CardColor_TextColor_and_Caption_should_be_modified_successfully(String iPadding, String cColor, String tColor, String cCaption) {	
		assertTrue(editDashboardOptions.areCardChartOptionsModified(chartTitle, iPadding, cColor, tColor, cCaption), "Chart options should be modified");
        attachScreenshotForWeb();   
	}
	
	
	
	//method clicks on save dashboard button from edit dashboard screen and dashboard screen as required
    @When("User clicks on Save Dashboard in the Edit Dashboard screen")
    public void user_clicks_on_save_dashboard_in_the_edit_dashboard_screen() {
        editDashboardOptions.clickSaveDashboard();
        attachScreenshotForWeb();
	}
    
    //method saves the modifications done
    @Then("Chart modifications should be saved successfully")
    public void chart_modifications_should_be_saved_successfully() {
        boolean isSaveDashboardClicked = editDashboardOptions.isSaveDashboardButtonClicked();  
        assertTrue(isSaveDashboardClicked, "Save Dashboard button should be clicked"); 
        attachScreenshotForWeb();     
        if (isSaveDashboardClicked) {
            System.out.println("\n Assertion Passed: User is able to click on Save dashboard button and dashboard is saved successfully!!");
        }
    }
    
    //method clicks on the cancel icon and verifies its functionality
    @When("User clicks on the Cancel icon in the Edit Dashboard screen")
    public void user_clicks_on_cancel_icon_in_the_edit_dashboard_screen() {
    	editDashboardOptions.clickCancelIcon();
        assertTrue(editDashboardOptions.verifyCancelClicked(), "Cancel icon should be clicked");
        attachScreenshotForWeb();
	}
    
    //method closes the edit dashboard screen
    @Then("Edit Dashboard screen should be closed")
    public void edit_dashboard_screen_should_be_closed() {
    	boolean cancelClicked = editDashboardOptions.verifyCancelClicked();
        assertTrue(cancelClicked, "Cancel button should be clicked"); 
        if (cancelClicked) {
            System.out.println("\n Assertion Passed: User is able to click on Cancel button and edit dashboard is closed successfully!!");
        }
        attachScreenshotForWeb();
    }
    
    //method clicks on save dashboard on the dashboard screen
    @When("clicks on Save Dashboard in the Edit Dashboard screen")
    public void clicks_on_Save_Dashboard_in_the_Edit_Dashboard_Screen() {
    	editDashboardOptions.clickSaveDashboard();
        assertTrue(editDashboardOptions.isSaveDashboardButtonClicked(),"Save Dashboard button should be clicked again");
        attachScreenshotForWeb();
        if(editDashboardOptions.isSaveDashboardButtonClicked()) {
        	System.out.println("\n Assertion Passed : Dashboard Saved Successfully!!");
        }
	}

    //method clicks on refresh button
	@When("User clicks on Refresh Dashboard in the View Dashboard page")
	public void clicks_on_refresh_dashboard_in_the_view_dashboard_page() {
		editDashboardOptions.clickRefreshDashboardBtn();
		attachScreenshotForWeb();
	}
	
	//Card chart verify if it is visible on dashboard after editing
	@Then("The changes should be verified on the View Dashboard page Title")
	public void the_changes_should_be_verified_on_the_view_dashboard_page() {
        assertTrue(editDashboardOptions.verifyCardChartOptions(chartTitle), "Card Chart options should be modified");
        attachScreenshotForWeb();
        if(editDashboardOptions.verifyCardChartOptions(chartTitle)) {   	
        System.out.println("\n Assertion Passed : Verification on view dashboard page successful");
	}
	}
}

