//Developed by Vaishnavi Zarad and refactored by Preeti Pal	

package com.cognizant.steps;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;

import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_DashboardPage;
import com.cognizant.pages.CIQD_LoginPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CIQD_DashboardStepDef extends MasterSteps {

	CIQD_LoginPage loginPage;
	CIQD_DashboardPage dashboardPage;
	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	

	public CIQD_DashboardStepDef() {
		loginPage = new CIQD_LoginPage(driver);
		dashboardPage = new CIQD_DashboardPage(driver);
	}

	// Method verifies if user is on HomePage
	@Given("User is on HomePage")
	public void user_is_on_HomePage() {
		attachScreenshotForWeb();

	}

	// Method verifies if user is able to clicks on Project
	@When("User Click on Project")
	public void user_clicks_on_project() {
		dashboardPage.clickProject();
		attachScreenshotForWeb();
	}

	// Method verifies if user is able to clicks on Dashboards 
	
	@When("User clicks on Dashboards")
	public void user_clicks_on_dashboards() {
		dashboardPage.clickDashboards();
		attachScreenshotForWeb();

	}

	// Method verifies if user is able to create dashboard
	@When("Create Dashboard with valid name")
	public void create_dashboard_with_valid_name() {
		
		String dashboardName = properties.getProperty("dashboardName");
		dashboardPage.enterDashboardName(dashboardName);
		attachScreenshotForWeb();
	}

	// Method verifies that user is able to create dashboard using plus icon
	@When("User clicks on Create Dashboard \\(plus icon) with existing dashboard name")
	public void user_clicks_on_create_dashboard_icon_with_existing_dashboard_name() {
		dashboardPage.clickplusIcon();
		String dashboardName = properties.getProperty("dashboardName");
		dashboardPage.enterDashboardName(dashboardName);
		attachScreenshotForWeb();
	}

	
	// Method verifies if dashboard is created successfully
	@Then("Verify dashboard is created successfully")
	public void dashboard_created_successfully() {
		dashboardPage.clickCreate();
		dashboardPage.verifyDashboardCreation("New");
		attachScreenshotForWeb();
		
	}

	// Method Verifies if dashboard is not created successfully
	@Then("Verify dashboard is not created successfully")
	public void dashboard_not_created_successfully() {
		dashboardPage.clickCreate();
		dashboardPage.verifyDashboardCreation("Existing");
		attachScreenshotForWeb();
		
	}
	@When("User clicks on Create Dashboard \\(plus icon) with {string}")
	public void user_clicks_on_create_dashboard_plus_icon_with(String dashboardName1) {
		dashboardPage.clickplusIcon();
		dashboardPage.enterDashboardName(dashboardName1);
		attachScreenshotForWeb();
	}
      
	//Method Verifies that create button is disabled
	@Then("Create button is disabled")
	public void create_button_is_disabled() {
		dashboardPage.createDisable();
		attachScreenshotForWeb();
		log.info("User not able to create Dashboard because create button is disabled");
	}

	//Method verifies that User able to selects a particular dashboard
	@When("User selects a particular Dashboard")
	public void user_clicks_on_dashboards_and_opens_existing_dashboard() {
		
		dashboardPage.openDashboard();
		attachScreenshotForWeb();
	}

	// Method verifies that user is able to delete dashboard successfully
	@Then("Verify dashboard deleted successfully")
	public void Verify_dashboard_deleted_successfully() {
		waitFor(3000);
		dashboardPage.deleteDashboard();
		attachScreenshotForWeb();
		String ActualTitle = dashboardPage.getPopupMessage();
		System.out.println(ActualTitle);
		String ExpectedTitle = "dashboard deleted successfully";
		// Now, assert to verify that the User is deleted Dashboard
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		log.info("User Deletes Dashboard");
	}

}
