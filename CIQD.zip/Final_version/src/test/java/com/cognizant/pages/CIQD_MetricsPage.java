// Scripted By Prasad Bhadke and Refactored by Prasad Bhadke
 
package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CIQD_MetricsPage extends CIQD_BasePage {
 
	public CIQD_MetricsPage(WebDriver driver) {
		super(driver);
	}
 
	WebDriver driver;
 
	private By metricsOption = By.xpath("//*[text()='Metrics ']");
	private By newmetrics = By.xpath("//button[text()='Add New' and @type='button']");
	private By metricName = By.name("metricName");
	private By cancelmetrics = By.xpath("//button[text()='Cancel' and @type='button']");
	private By viewMetrics = By.xpath("//span[text()='C2M_ExecutionSummary']");
	private By manageMetric = By.xpath("//button[@type='button' and text()='Cancel']");
	
 
	public void clickOnMetric() {
		clickOnWebElement(metricsOption);
	}
 
	public void addDetailsOfMetric() {
		clickOnWebElement(newmetrics);
		sendKeysOnWebElement(metricName, "PDP_Sample_metric");
	}
 
	public void clickOnCancel() {
		clickOnWebElement(cancelmetrics);
	}
 
	public void viewMetric() {
		clickOnWebElement(viewMetrics);
		clickOnWebElement(manageMetric);
	}
	public String verifyNewMetrics() {
		String newMetrics = getTextOnWebElement(newmetrics);
		return newMetrics;
	}
	public String verifyExistingMetrics() {
		String existingMetrics = getTextOnWebElement(viewMetrics);
		return existingMetrics;
	}
}
