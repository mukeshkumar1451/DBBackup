package com.cognizant.pages;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cognizant.framework.DriverManager;
import com.cognizant.steps.MasterSteps;

//Developed By Team-A , Team-B , Team-C

public class CIQD_Generics extends MasterSteps {

	WebDriver driver;

	public CIQD_Generics(WebDriver driver) {
		this.driver = driver;
	}

	// Returns WebElemt
	public WebElement getWebElement(By locator) {
		WebElement webElement = null;
		try {
			webElement = driver.findElement(locator);
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
		return webElement;
	}

//To Click	
	public void clickOnWebElement(By locator) {
		try {
			waitUntilElementLocated(locator, 3000);
			driver.findElement(locator).click();
		} catch (Exception e) {
			clickOnWebElementByActionsClass(locator);
		}

	}

// To Send Keys	
	public void sendKeysOnWebElement(By locator, String value) {

		try {
			driver.findElement(locator).sendKeys(value);
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// Enabled Element	
	public boolean isWebElementEnabled(By locator) {

		boolean flag = false;
		try {
			flag = driver.findElement(locator).isEnabled();
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
		return flag;
	}


// To Get Text	
	public String getTextOnWebElement(By locator) {

		String text = null;
		try {
			text = driver.findElement(locator).getText();
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
		return text;
	}

// Click By Action Class	
	public void clickOnWebElementByActionsClass(By locator) {

		try {
			Actions action = new Actions(driver);
			action.click(driver.findElement(locator)).build().perform();
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// Clear Text	
	public void clearTextOnWebElement(By locator) {
		try {
			driver.findElement(locator).clear();
		} catch (NoSuchElementException e) {
			System.out.println("Exception : " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}

	}

//To Launch Browser	
	public void launchUrlOnBrowser() {

		try {
			String appUrl = properties.getProperty("ApplicationUrl");
			driver.get(appUrl);
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// TO Refresh Webpage	
	public void refreshWebpage() {

		try {
			driver.navigate().to(driver.getCurrentUrl());
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// Explacit Wait
	public void waitUntilElementLocated(By by, long timeOutInSeconds) {
		try {
			new WebDriverWait(DriverManager.getWebDriver(), Duration.ofSeconds(timeOutInSeconds))
					.until(ExpectedConditions.presenceOfElementLocated(by));
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// Explacit Wait	
	public void waitUntilElementVisible(By by, long timeOutInSeconds) {

		try {
			(new WebDriverWait(DriverManager.getWebDriver(), Duration.ofSeconds(timeOutInSeconds)))
					.until(ExpectedConditions.visibilityOfElementLocated(by));
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}

// Explacit Wait	
	public void waitUntilElementEnabled(By by, long timeOutInSeconds) {
		try {
			(new WebDriverWait(DriverManager.getWebDriver(), Duration.ofSeconds(timeOutInSeconds)))
					.until(ExpectedConditions.elementToBeClickable(by));
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}

	}

// Explacit Wait	
	public void waitUntilPageLoaded(long timeOutInSeconds) {

		try {
			WebElement oldPage = DriverManager.getWebDriver().findElement(By.tagName("html"));

			(new WebDriverWait(DriverManager.getWebDriver(), Duration.ofSeconds(timeOutInSeconds)))
					.until(ExpectedConditions.stalenessOf(oldPage));
		} catch (Exception e) {
			System.out.println("Exception : " + e.getMessage());
		}

	}


// To Click ElementByJavaScript
	public void clickElementByJavaScript(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click()", element);
		} catch (Exception e) {
			System.out.println("Error occurred while clicking the element: " + e.getMessage());
		}
	}

// To move Element
	public void moveToElement(By locator) {
		try {
			Actions actions = new Actions(driver);
			WebElement element = driver.findElement(locator);
			actions.moveToElement(element).build().perform();
			System.out.println("Moved to element with locator: " + locator);
		} catch (Exception e) {
			System.out.println("An error occurred while moving to the element: " + e.getMessage());
		}
	}

// To Select Visible Element(Drop Down)
	public void selectByVisibleText(By locator, String text) {
		try {
			Select select = new Select(driver.findElement(locator));
			select.selectByVisibleText(text);
			System.out.println("Selected option with visible text: " + text);
		} catch (Exception e) {
			System.out.println("An error occurred while selecting the option with visible text: " + e.getMessage());
		}
	}

// To sendKeysWithControl
	public void sendKeysWithControl(By locator, String Text) {
		try {
			WebElement element = driver.findElement(locator);
			Actions action = new Actions(driver);
			action.sendKeys(element, Text).keyUp(Keys.CONTROL).perform();
		} catch (Exception e) {
			System.out.println("An error occurred while sending keys with control: " + e.getMessage());
		}
	}

// For Comparison 
	@SuppressWarnings("unlikely-arg-type")
	public boolean compareUserIds(String userId1, By Locator) {
		try {
			WebElement element = driver.findElement(Locator);
			return userId1.equals(element);
		} catch (Exception ex) {
			System.out.println("Exception occurred: " + ex.getMessage());
			return false;
		}
	}

// To isElementDisabled
	public boolean isElementDisabled(By Locator) {
		try {
			WebElement element = driver.findElement(Locator);
			return !element.isEnabled();
		} catch (Exception ex) {
			System.out.println("Exception occurred: " + ex.getMessage());
			return false;
		}

	}

	// To check if the element is currently visible 
			public boolean isElementVisible(By locator) {
			    try {
			        return driver.findElement(locator).isDisplayed();
			    } catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.TimeoutException e) {
			        return false;
			    }
			}
			
	// To check if the element is present in the DOM		
			public boolean isElementPresent(By locator) {
			    try {
			        new FluentWait<>(driver).withTimeout(Duration.ofSeconds(10)).until(ExpectedConditions.presenceOfElementLocated(locator));
			        return true;
			    } catch (Exception e) {
			        return false;
			    }
			}
			
	// Deletes any text present in the text field and enters the text passed as parameter	
		    public void clearAndSendKeys(By elementLocator, String text) {
		        try {
		            driver.findElement(elementLocator).clear();
		            driver.findElement(elementLocator).sendKeys(text);
		        } catch (Exception e) {
		            handleException("Error while modifying chart options", e);
		        }
		    }
		    public void handleException(String errorMessage, Exception e) {
		        System.err.println(errorMessage + ": " + e.getMessage());
		        // You can customize the exception handling based on your requirements
		        // For example: log the exception, take a screenshot, etc.
		        throw new RuntimeException(errorMessage, e);
		    }
		
	}
