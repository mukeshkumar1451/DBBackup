//Developed by Vaishnavi Zarad and refactored by Preeti Pal

package com.cognizant.pages;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;

public class CIQD_DashboardPage extends CIQD_BasePage {
	final static Logger log = getLogger(lookup().lookupClass());
	

	public CIQD_DashboardPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}

	private By dashboardsButton = By.xpath("//button[text()='DashBoards']");
	private By plusIcon = By.xpath("//button[@title='Create Dashboard']");
	private By dashNameInputField = By.xpath("//input[@name='newDashBoardName']");
	private By createButton = By.xpath("//button[text()='Create']");

	private By openDashButton(){
	String dashBoardName = properties.getProperty("dashboardName");
	return By.xpath("//button[text()='"+dashBoardName+"']");
	}
	private By cancelBtn = By.xpath("//*[contains(text(),'Cancel')]");

	// Preeti Pal
	// for checking whether the dashboard is created or not
	private By verifyDashboardisCreate = By.xpath("//span[@class='is-editable']");
	private By deleteDashButton = By.xpath("//div[@class='btn-group btn-outline-primary btn-md btn-icon']/button[@title='Delete Dashboard']");

	// Method is used to Click on respective dashboard
	public void clickDashboards() {
		waitUntilElementLocated(dashboardsButton, 30);
		clickOnWebElement(dashboardsButton);

	}
	
	// if the dashboard is created then click on plus icon else no need to click on plus icon.
	public void clickplusIcon() {
		clickOnWebElement(plusIcon);	
	}

	//Method is used to enter Dashboard Name
	public void enterDashboardName(String dashboardName) {
		Boolean result = isWebElementEnabled(dashNameInputField);
		if(result)
		{
			waitUntilElementLocated(dashNameInputField, 30);
			sendKeysOnWebElement(dashNameInputField, dashboardName);
		}
		else{
			clickOnWebElement(plusIcon);
			waitUntilElementLocated(dashNameInputField, 30);
			System.out.println(driver.findElement(dashNameInputField).isEnabled());
			sendKeysOnWebElement(dashNameInputField, dashboardName);
		}
	}

	// This method clicks on create button from dashboard creation dialog box
	public void clickCreate() {
		waitUntilElementLocated(createButton, 2000);
		clickOnWebElement(createButton);
	}

	
	// To verify that the dashboard is created or not
	public void verifyDashboardCreation(String status) {
		if (status.equals("New")) {
			try {
				waitUntilElementLocated(verifyDashboardisCreate, 1000);
				log.info("User created dashboard successfully");
			} catch (Exception e) {
				System.out.println("Dashboard is not created ");
			}

		} else {
			log.info(getPopupMessage());
		}
	}

	
	// To verify if the create button is disabled
	public void createDisable() {
		waitUntilElementLocated(createButton, 2000);
		Boolean result = isWebElementEnabled(createButton);
		if (result) {
			log.info("Yes ! Create Button is Present");
		} else {
			log.info("NO ! Create Button is not Present");
		}
	}

	
	// This method is opens the respective Dashboard
	public void openDashboard() {
		waitUntilElementLocated(openDashButton(), 6000);
		clickOnWebElement(openDashButton());
	}

	
	// This method is used to delete the respective Dashboard
	public void deleteDashboard() {
		waitUntilElementVisible(openDashButton(), 3000);
		clickOnWebElementByActionsClass(deleteDashButton);
	}

}