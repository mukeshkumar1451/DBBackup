// Scripted By Himanshi Verma and Refactored by Abhishek Gouraj
 
package com.cognizant.pages;
 
import java.util.Properties;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
import com.cognizant.framework.Settings;
 
public class CIQD_RolesPage extends CIQD_BasePage {
 
	public CIQD_RolesPage(WebDriver driver) {
		super(driver);
	}
 
	WebDriver driver;
 
	public Properties properties = Settings.getInstance();
 
	private By RoleProfile = By.xpath("//*[text()='Roles ']");
	private By AddNewROLE = By.xpath("//*[text()='Add New' and @type='button']");
	private By RoleName = By.xpath("//input[@name='name' or @placeholder='Role Name']");
	private By Description = By.xpath("//input[@name='description' and @placeholder='Description']");
	private By Permission = By.xpath("//*[text()='Permissions']");
	private By AdminPermission = By.xpath("//*[text()='Admin Permission']");
	private By verifyProfilePage = By.xpath("//*[text()='admin user1']");
	private By verifyExistingUsers = By.xpath("//*[text()='Users']");
	private By verifyNewRoleAdded = By.xpath("//*[text()='Manage Roles']");
	private By verifyExistingRoles = By.xpath("//*[text()='Roles']");
 
	public void navigateToRoleOption() {
		clickOnWebElement(RoleProfile);
	}
 
	public void clickOnAddNewRollButton() {
		clickOnWebElement(AddNewROLE);
	}
 
	public void clickOnCreateRole() {
		String role = properties.getProperty("Roll_Name");
		String desc = properties.getProperty("Description");
		sendKeysOnWebElement(RoleName, role);
		sendKeysOnWebElement(Description, desc);
		clickOnWebElement(Permission);
		clickOnWebElement(AdminPermission);
		clickOnWebElement(AddNewROLE);
	}
	public String verifyProfilePage() {
		String profilePage = getTextOnWebElement(verifyProfilePage);
		return profilePage;
	}
	public String verifyExistingUsers() {
		String usersPage = getTextOnWebElement(verifyExistingUsers);
		return usersPage;
	}
	public String verifyNewRoleAdded() {
		String newRole = getTextOnWebElement(verifyNewRoleAdded);
		return newRole;
	}
	public String verifyExistingRoles() {
		String existingRole = getTextOnWebElement(verifyExistingRoles);
		return existingRole;
	}
 
}