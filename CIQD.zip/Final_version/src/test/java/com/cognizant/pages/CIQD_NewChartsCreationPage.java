//Developed and Refactored by Akash Panchal and Vijay Raskar

package com.cognizant.pages;
 
import java.time.Duration;
 
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

//import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;

import org.testng.Assert;
 
public class CIQD_NewChartsCreationPage extends CIQD_BasePage {
 
	public CIQD_NewChartsCreationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
 
	private By existingDashboards = By.xpath("//button[normalize-space()='DashBoards']");
	private By editPencil = By.xpath("//clr-icon[@shape='pencil']");
	private By dragBarChart = By.xpath("//clr-icon[@shape='bar-chart']"); 
	private By dropBarChart = By.xpath("//div[@class='gridster-row ng-star-inserted'][1]"); 
	private By dropBarChart_Click = By.xpath("//div[@class='content flex-col full']"); 
	private By resizeChart = By.xpath("//div[@class='gridster-item-resizable-handler handle-se ng-star-inserted']");
	private By charttab = By.xpath("//*[@class=\"number-card chart clickable\"]");
	private By charts = By.xpath("//button[@class=\"btn btn-link nav-link ng-star-inserted\"]");
	private By plusCircleClick = By.xpath("//span[@class='is-link ng-star-inserted']/clr-icon[@shape='plus-circle']"); 
	private By clickOnJIRA = By.xpath("//div[normalize-space()='Jira']"); 
	private By clickOnCardChart = By.xpath("//div[normalize-space()='card-chart']"); 
	private By infoName = By.name("item-info-name"); 
	private By infoDescription = By.name("item-info-description"); 
	private By clickOnDataBTN = By.xpath("//button[text()='Data']"); 
	private By groupByDropdown_Click = By.className("clr-accordion-angle"); 
	private By groupName = By.xpath("//select[@placeholder='GroupBy']"); 
	private By aggregateDropDown_Click = By.cssSelector(
			"body > app-root:nth-child(1) > clr-main-container:nth-child(2) > div:nth-child(2) > div:nth-child(2) > app-wrapper:nth-child(2) > ng-component:nth-child(2) > app-dashboard-modal:nth-child(2) > div:nth-child(1) > div:nth-child(1) > ng-component:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > item-data-editor:nth-child(1) > form:nth-child(1) > clr-tabs:nth-child(1) > section:nth-child(2) > clr-accordion:nth-child(1) > clr-accordion-panel:nth-child(2) > div:nth-child(1) > div:nth-child(1) > button:nth-child(1) > span:nth-child(2) > clr-icon:nth-child(1)");
	private By field = By.xpath("//select[@placeholder='Agg.Field']");
	private By optionBTNClick = By.xpath("//button[text()='Options']");
	private By title = By.className("clr-input-wrapper");
	private By saveChartClick = By.xpath("//button[@title='Save Dashboard']");
	private By saveCardChartClick = By.cssSelector("clr-icon[shape='floppy']");
	private By clickOnFetchData = By.xpath("//button[@title='Refresh Preview']");
	private By successChartMSG = By.cssSelector("#toast-container");
	private By cancelIcon = By.xpath("//button[@title='Cancel']");
	private By refreshIcon = By.xpath("//button[@title='Refresh Dashboard']");
	private By verifyDatasource = By.xpath("//span[text()='Data Source ']");
	private By optionsTitleInputField = By.xpath("//input[@placeholder ='title']");
	private By dashboardNameClick() {
		String dashNameClick = properties.getProperty("dashboardName");
		return By.xpath("//button[text()='"+dashNameClick+"']");
	}

	 //this method is used to click on the respective dashboard button
	public void existingDashboardsClick() {
		waitUntilElementLocated(existingDashboards,3000);
		clickOnWebElement(existingDashboards);
	}

	 //this method is used to click on the edit button
	public void editPencilClick() {
		clickOnWebElement(dashboardNameClick());
		waitUntilElementLocated(editPencil,3000);
		clickOnWebElement(editPencil);
	}

	 //this method is used to add new chart
	public void addNewChart() {
		
		waitUntilElementLocated(dragBarChart,3000);
		WebElement src = getWebElement(dragBarChart);
		waitUntilElementLocated(dropBarChart,3000);
		WebElement dest = getWebElement(dropBarChart);
		Actions action = new Actions(driver);
		action.clickAndHold(src).pause(Duration.ofSeconds(2)).moveToElement(dest).pause(Duration.ofSeconds(2)).release()
		.build().perform();
	}

	 //this method is used to resize the added new chart
	public void reSizeNewChart() {
		WebElement resize_Chart = driver.findElement(resizeChart);
		Actions action = new Actions(driver);
		action.dragAndDropBy(resize_Chart, 200, 100).perform();
		waitUntilElementLocated(dropBarChart_Click, 3000);
		clickOnWebElement(dropBarChart_Click);
	}

	 //this method is used to navigate to the JIRA data source
	public void navigateToJIRADataSource() {
		waitUntilElementVisible(plusCircleClick, 3000);
		clickOnWebElement(plusCircleClick);
		clickOnWebElement(clickOnJIRA);
		clickOnWebElement(clickOnCardChart);
	}

	 //this method is used to click on the Info section button
	public void infoSection() {
		
		waitUntilElementLocated(infoName, 3000);
		clearTextOnWebElement(infoName);
		clickOnWebElement(infoName);
		sendKeysOnWebElement(infoName, "Card Chart");
		waitUntilElementLocated(infoDescription, 3000);
		clickOnWebElement(infoDescription);
		clearTextOnWebElement(infoDescription);
		sendKeysOnWebElement(infoDescription, "Card Data");
	}

	 //this method is used to click on the data button
	public void dataClick() {
		clickOnWebElement(clickOnDataBTN);
	}

	 //this method is used to click on the datasection button
	public void dataSection(String statusName) {
		clickOnWebElement(groupByDropdown_Click);
		Actions action = new Actions(driver);
		clickOnWebElement(groupName);
		action.sendKeys(statusName).click();
		sendKeysOnWebElement(groupName, "statusName");
	}

	 //this method is used to click on the aggregate button
	public void aggregate(String priorityId) {
		clickOnWebElement(aggregateDropDown_Click);
		waitUntilElementLocated(field, 3000);
		clickOnWebElement(field);
		Actions action = new Actions(driver);
		action.sendKeys(priorityId).click();
		sendKeysOnWebElement(field, "priorityId");
	}

	 //this method is used to click on the option button
	public void optionsClick(String title) {
		clickOnWebElement(optionBTNClick);
		clearTextOnWebElement(optionsTitleInputField);
		sendKeysOnWebElement(optionsTitleInputField,title);
	}

	 //this method is used to click on the save button
	public void saveDashboard() {
		clickOnWebElement(clickOnFetchData);
		clickOnWebElement(saveCardChartClick);
		waitUntilElementLocated(saveChartClick, 3000);
		attachScreenshotForWeb();
		clickOnWebElement(saveChartClick);
		attachScreenshotForWeb();
	}
	
	 //this method is used to click on the cancel button
	public void clickOnCancelIcon() {
		clickOnWebElement(cancelIcon);
	}
	
	//this method is used to click on the refresh button
	public void clickOnRefreshIcon() {
		refreshWebpage();
	}

	 //this method is used to verify data source page
	public String verifyDataSourcePage() {
		String datasource = getTextOnWebElement(verifyDatasource);
		String ActualResult =  datasource;
		String ExpectedResult = "Data Source JIRA";
		Assert.assertEquals(ExpectedResult,ActualResult);
		return datasource;
	}

	 //this method is used to print the successful chart creation message
	public void NewChartCreatedMsg() {	
		clickOnWebElement(saveChartClick);
		waitUntilElementLocated(successChartMSG,3000);
		System.out.println(getTextOnWebElement(successChartMSG));
		attachScreenshotForWeb();
	}
}
 