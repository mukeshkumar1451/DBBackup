//Developed by Shivani, Dinesh and Prafull

package com.cognizant.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CIQD_RegistrationPage extends CIQD_BasePage {

	public CIQD_RegistrationPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	private By firstNameInputField = By.name("firstName");
	private By lastNameInputField = By.name("lastName");
	private By emailInputField = By.name("email");
	private By passwordInputField = By.name("password");
	private By confirmedPasswordInputField = By.name("confirmPassword");
	private By createAccountLink = By.className("btn-login");
	private By eyeIcon = By.xpath("//clr-icon[@title='Show']");
	
	

	//  Method is used to click on create account link
	public void clickOnCreateAccount() {
		clickOnWebElement(createAccountLink);
	}

	//  Method is used to enter first name
	public void enterFirstName(String fname) {
		sendKeysOnWebElement(firstNameInputField, fname);
	}

	// Method is used to enter last name
	public void enterLastName(String lname) {
		sendKeysOnWebElement(lastNameInputField, lname);
	}

	//  Method is used to enter email ID 
	public void enterEmailID(String emailid) {
		sendKeysOnWebElement(emailInputField, emailid);
	}

	//  Method is used to enter password
	public void enterPassword(String pass) {
		sendKeysOnWebElement(passwordInputField, pass);
	}

	// Method is used to enter confirmed password
	public void enterConfirmedPassword(String conmpass) {
		sendKeysOnWebElement(confirmedPasswordInputField, conmpass);
	}

	// Method is used to verify that create account button disabled
	public void createAccountDisable() {

		Boolean status = isWebElementEnabled(createAccountLink);
		if (status) {
			System.out.println("Create Account button is Enabled");
		} else {
			System.out.println("Create Account button is disabled");
		}
	}

	
	// This method is used to click on eye icon
	public void clickOnEyeIcon() {
		clickOnWebElement(eyeIcon);
		
	}

}
