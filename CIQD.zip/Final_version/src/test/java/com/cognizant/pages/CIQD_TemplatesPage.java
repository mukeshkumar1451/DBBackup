// Scripted By Shreshth Roy and Manisha Patil
//Refactored by Shreshth Roy
 
package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CIQD_TemplatesPage extends CIQD_BasePage {
 
	public CIQD_TemplatesPage(WebDriver driver) {
		super(driver);
	}
 
	WebDriver driver;
 
	private By TemplateS = By.xpath("(//span[@class='nav-text'])[5]");
	private By MyTemplate = By.xpath("(//button[contains(@class,'clr-treenode-caret')])[1]");
	private By Default = By.xpath("(//button[contains(@class,'clr-treenode-caret')])[2]");
	private By VerifyTemplatePage = By.xpath("//*[text()='Templates']");
	private By VerifyDefaultTemplate = By.xpath("//*[text()=' default ']");
 
 
	public void ClickonTemplates() {
		clickOnWebElement(TemplateS);
	}
 
	public void ClickonMyTemplate() {
		clickOnWebElement(MyTemplate);
 
	}
 
	public void ClickonDefault() {
		clickOnWebElement(Default);
	}
	public String verifyTemplatePage() {
		String templatePage = getTextOnWebElement(VerifyTemplatePage);
		return templatePage;
	}
	public String verifyDefaultTemplate() {
		String defaultTemplate = getTextOnWebElement(VerifyDefaultTemplate);
		return defaultTemplate;
	}
 
}