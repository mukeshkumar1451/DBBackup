//Developed By : Aditya Dharmapurikar and Vaishnavi Zarad
//Refactored By : Aditya Dharmapurikar and Kalyani Chaudhary

package com.cognizant.pages;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;

import com.cognizant.framework.DriverManager;

public class CIQD_LoginPage{
	final static Logger log = getLogger(lookup().lookupClass());
	WebDriver driver = DriverManager.getWebDriver();

	public CIQD_LoginPage(WebDriver driver) {
		this.driver = driver;
	}
	CIQD_Generics generics = new CIQD_Generics(driver);
	CIQD_BasePage basepage = new CIQD_BasePage(driver);
	
	
	private By CreateAccountLink = By.xpath("//a[text()=' Create Account ']");
	private By usernameInputField = By.name("username");	
	private By passwordInputField = By.name("password");
	private By LogInButton = By.xpath("//button[text()='Login']");
	private By nameOftheUser = By.id("toast-container");
	private By LogInBtnLocator = By.xpath("//button[@type='submit']");
	private By AdminValidationLocator = By.xpath("//label[@role='menuitem']");


	public void clickOnCreateAccountLink() {
		generics.clickOnWebElement(CreateAccountLink);
	}
	
	public void launchUrl()
	{
		generics.launchUrlOnBrowser();
	}
	
	public void loginIntoCIQD(String UserName, String Password) {
		generics.waitUntilElementLocated(usernameInputField,3000);
		generics.sendKeysOnWebElement(usernameInputField,UserName);
		generics.sendKeysOnWebElement(passwordInputField,Password);
		generics.clickOnWebElement(LogInButton);
		
	}

	public void enteruserName(String UserName) {
		generics.sendKeysOnWebElement(usernameInputField, UserName);
	}

	public void enterPassword(String Password) {
		generics.sendKeysOnWebElement(passwordInputField,Password);

	}

	public void loginDisable() {
		Boolean nn = generics.isWebElementEnabled(LogInButton);
		if (nn) {
			System.out.println("Login Button is Present");
		} else {
			System.out.println("Login Button is not Present");
		}

	}

	public void clickOnLoginButton() {
		generics.waitUntilElementLocated(LogInButton,3000);
		generics.clickOnWebElement(LogInButton);

	}
	
	public void getNameOfTheUser() {
		
		String User = driver.findElement(nameOftheUser).getText();
		generics.getTextOnWebElement(nameOftheUser);
		
		System.out.println("Current User : " + User);
		
	}
	public void Profile_Validation(String Username) {
		generics.waitUntilElementVisible(AdminValidationLocator,5);
		generics.waitUntilElementLocated(AdminValidationLocator,5);
		generics.getTextOnWebElement(AdminValidationLocator);
		basepage.compareUserIds(Username,AdminValidationLocator);
	}
	public void LoginBtnStatus() {
		generics.isWebElementEnabled(LogInBtnLocator);
	}

	
}

	


