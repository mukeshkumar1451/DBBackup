// Scripted By Saloni Sewani and Refactored by Abhishek Gouraj
 
package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CIQD_TeamsPage extends CIQD_BasePage {
 
	public CIQD_TeamsPage(WebDriver driver) {
		super(driver);
	}
 
	WebDriver driver;
 
	private By teams = By.xpath("//*[text()='Teams ']");
	private By Addnew = By.xpath("//button[text()='Add New']");
	private By Cancel = By.xpath("//button[text()='Cancel']");
	private By ViewTeam = By.xpath("//span[text()='Team_1'] ");
	private By ExistingTeams = By.xpath("//*[text()='Manage Teams']");
 
	public void createNewTeam() {
		clickOnWebElement(Addnew);
		clickOnWebElement(Cancel);
	}
 
	public void navigateToTeams() {
		clickOnWebElement(teams);
	}
 
	public void viewExistingTeams() {
		clickOnWebElement(ViewTeam);
	}
	
	public String verifyAddNewTeam() {
		String addnew = getTextOnWebElement(Addnew);
		return addnew;
	}
	
	public String verifyExistingTeam() {
		String existingTeam = getTextOnWebElement(ExistingTeams);
		return existingTeam;
	}
 
}