// Scripted By Ashish Dupargude and Refactored by Shreshth Roy

package com.cognizant.pages;

import org.openqa.selenium.WebDriver;

public class CIQD_UsersPage extends CIQD_BasePage {
 
	public CIQD_UsersPage(WebDriver driver) {
		super(driver);
	}
 
}
