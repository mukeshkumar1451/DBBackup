//Developed By : Akash Panchal
//Refactored By : Nidhi Singh and Saloni Sewani

package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
public class CIQD_OrgPage extends CIQD_BasePage {
 
	//Constructor of CIQD_Create_New_ORG_Page Class
	public CIQD_OrgPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
 
	//Locator
	private By NOrgLocator = By.xpath("//label[normalize-space()='New ORG']"); 
	private By ONameLocator = By.name("organizationName");
	private By ODescriptionLocator = By.name("organizationDesc");
	private By CBtnLocator = By.xpath("//button[@type='submit']");
	private By OrgCreateLocator = By.id("toast-container");
	private By ErrorMesLocator = By.cssSelector("div[aria-label='please provide valid inputs']");
	
	// Method to Click on ORG and then to Enter details for NEW ORG Creation
	public void createOrg(String OrgName, String OrgDescription) {
		clickOnORG();
		clickOnWebElement(NOrgLocator);
		clickOnWebElement(ONameLocator);
		sendKeysOnWebElement(ONameLocator, OrgName);
		clickOnWebElement(ODescriptionLocator);
		sendKeysOnWebElement(ODescriptionLocator, OrgDescription);
		clickOnWebElement(CBtnLocator);
		clickOnWebElement(OrgCreateLocator);
	}
 
	// Method to Get Text Message for ORG Successful creation
	public String orgCreated_msg() {
		return getTextOnWebElement(OrgCreateLocator);
	}
 
	// Method to Get Error Text Message after Unsuccessful ORG Creation
	public String Error_Msg() {
		return getTextOnWebElement(ErrorMesLocator);
	}
 
}