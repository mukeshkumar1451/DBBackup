//Developed By : Vijay Raskar and Abhishek Gouraj
//Refactored By : Aditya Dharmapurikar and Kalyani Chaudhary

package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
 
public class CIQD_LobPage extends CIQD_BasePage {
 
	// Constructor of CIQD_Create_New_LOB_Page Class
	public CIQD_LobPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	//Locators
	private By NewLobLocator = By.xpath("//label[normalize-space()='New LOB']");
	private By LobNameLocator = By.xpath("//input[@name='lobName']");
	private By LobDescriptionLocator = By.name("lobDescription");
	private By LobOrgDetailLocator = By.xpath("//select[@name='orgId']");
//	private By LobOrgLocator = By.xpath("//*[text()= '" + srcTool + "' and @class='ng-star-inserted']");
	private By CBtnLocator = By.xpath("//button[@type='submit']");
	private By LobCreateLocator = By.id("toast-container");
	private By ErrorMesLocator = By.cssSelector("div[aria-label='please provide valid inputs']");
	
	// Method to Click on New LOB Tab and Fill the details for creating New LOB
	public void fillLobDetails(String LobName, String LobDescription) {
		clickOnLOB();
		clickOnWebElementByActionsClass(NewLobLocator);
		clickOnWebElementByActionsClass(LobNameLocator);
		sendKeysOnWebElement(LobNameLocator,LobName);
		clickOnWebElementByActionsClass(LobDescriptionLocator);
		sendKeysOnWebElement(LobDescriptionLocator,LobDescription);	
	}
	
	// Method to Fill ORG Details in LOB Creation
	public void createLobWithOrg(String OrgName) throws InterruptedException {
		clickOnWebElement(LobOrgDetailLocator);
		clickOnWebElement(By.xpath("//option[contains(text(),'"+OrgName+"')]"));
		clickOnWebElement(CBtnLocator);
		getTextOnWebElement(LobCreateLocator);
	}
	
	// Method to get Text Message when ORG is not Filled While LOB Creation
	public void createLobWithOutOrg() {
		clickOnWebElement(CBtnLocator);
		getTextOnWebElement(LobCreateLocator);
	}
	
	// Method to get Text Message after Successful LOB Creation   
	public String lobCreatedmsg() {
		return getTextOnWebElement(LobCreateLocator);
	}
	
	// Method to get Error Text Message after Unsuccessful LOB Creation   
	public String Error_Msg() {
		return getTextOnWebElement(ErrorMesLocator);
	}
 
 
}