package com.cognizant.collector.DatabaseCollector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseCollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
