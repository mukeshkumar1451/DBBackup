package com.cognizant.collector.DatabaseCollector.Initializer;



import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class ApplicationInitializer implements CommandLineRunner {

    private final ConfigurableApplicationContext applicationContext;

    public ApplicationInitializer(ConfigurableApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("Application started. Waiting for API call to trigger data transfer...");
        // No data transfer logic here. It will be handled by the controller.
    }

    public void exitApplication() {
        System.out.println("Shutting down the application...");
        applicationContext.close();
    }
}

























//package com.cognizant.collector.DatabaseCollector.Initializer;
//
//
//
//import com.cognizant.collector.DatabaseCollector.service.DataTransferService;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.ConfigurableApplicationContext;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//@Component
//public class ApplicationInitializer implements CommandLineRunner {
//
//    private final DataTransferService dataTransferService;
//    private final ApplicationContext applicationContext;
//
//    public ApplicationInitializer(DataTransferService dataTransferService, ApplicationContext applicationContext) {
//        this.dataTransferService = dataTransferService;
//        this.applicationContext = applicationContext;
//    }
//
//    @Override
//    public void run(String... args) throws Exception {
//        System.out.println("Application started. Beginning data transfer...");
//
//        // Perform the data transfer
//        dataTransferService.transferAllCollections("EP"); // Default key; this can be changed
//
//        System.out.println("Data transfer completed.");
//
//        // Exit the application
//        exitApplication();
//    }
//
//    private void exitApplication() {
//        // Exit the application gracefully
//        ((ConfigurableApplicationContext) applicationContext).close();
//        System.exit(0);
//    }
//}











//import com.cognizant.collector.DatabaseCollector.Scheduler.SchedulerInfo;
//import com.cognizant.collector.DatabaseCollector.service.DataTransferService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.context.annotation.Profile;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.stereotype.Component;
//
//import java.text.SimpleDateFormat;
//import java.util.List;
//import java.time.LocalDateTime;
//import java.time.ZoneOffset;
//import java.time.format.DateTimeFormatter;
//
//@Component
//@Profile("!test") // Only run this initializer if not in test profile
//public class ApplicationInitializer implements CommandLineRunner {
//
//    @Autowired
//    private MongoTemplate targetMongoTemplate;
//
//    @Autowired
//    private DataTransferService dataTransferService;
//
//    private static final DateTimeFormatter SCHEDULER_INFO_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//
//    @Override
//    public void run(String... args) throws Exception {
//        printSchedulerInfo();
//    }
//
//    private void printSchedulerInfo() {
//        System.out.println("Scheduler Info:");
//        List<SchedulerInfo> schedulerInfos = targetMongoTemplate.findAll(SchedulerInfo.class, "SchedulerInfo");
//
//        if (schedulerInfos != null && !schedulerInfos.isEmpty()) {
//            schedulerInfos.forEach(info -> {
//                System.out.println("Collection Name: " + (info.getCollectionName() != null ? info.getCollectionName() : "N/A"));
//                System.out.println("Jira Project Key: " + (info.getJiraProjectKey() != null ? info.getJiraProjectKey() : "N/A"));
//                System.out.println("Last Run: " + (info.getLastRun() != null ? SCHEDULER_INFO_DATE_FORMAT.format(info.getLastRun().toInstant()) : "N/A"));
//                System.out.println("Status: " + (info.getStatus() != null ? info.getStatus() : "N/A"));
//                System.out.println("--------------------------------");
//            });
//        } else {
//            System.out.println("No SchedulerInfo records found.");
//        }
//    }
//}


