package com.cognizant.collector.DatabaseCollector.service;

import com.cognizant.collector.DatabaseCollector.beans.RTS.Defect;
import com.cognizant.collector.DatabaseCollector.beans.RTS.TestCase;
import com.cognizant.collector.DatabaseCollector.beans.RTS.Userstories;
import com.cognizant.collector.DatabaseCollector.Scheduler.SchedulerInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DataTransferService {

    @Autowired
    private MongoTemplate sourceMongoTemplate;

    @Autowired
    private MongoTemplate targetMongoTemplate;

    private static final int BATCH_SIZE = 2000;
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm");
    private static final SimpleDateFormat SCHEDULER_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    public void transferAllCollections(String jiraProjectKey) {
        if (jiraProjectKey == null || jiraProjectKey.trim().isEmpty()) {
            throw new IllegalArgumentException("jiraProjectKey must not be null or empty");
        }

        ensureDatabaseAndCollections();

        transferCollection("Userstories", Userstories.class, jiraProjectKey);
        transferCollection("Defect", Defect.class, jiraProjectKey);
        transferCollection("testcase", TestCase.class, jiraProjectKey);

        // Optionally exit after data transfer
        System.exit(0);
    }

    private void ensureDatabaseAndCollections() {
        Set<String> collectionNamesSet = new HashSet<>(targetMongoTemplate.getCollectionNames());
        List<String> collectionNames = new ArrayList<>(collectionNamesSet);
        List<String> requiredCollections = Arrays.asList("Userstories", "Defect", "testcase", "SchedulerInfo");

        for (String collectionName : requiredCollections) {
            if (!collectionNames.contains(collectionName)) {
                targetMongoTemplate.createCollection(collectionName);
                System.out.println("Created collection: " + collectionName);
            }
        }
    }

    private <T> void transferCollection(String collectionName, Class<T> pojoClass, String jiraProjectKey) {
        int page = 0;
        List<T> batch;

        System.out.println("Fetching data from collection " + collectionName + "...");

        do {
            System.out.println("Fetching page " + page + " from collection " + collectionName + "...");
            batch = fetchDataBatch(collectionName, pojoClass, page, BATCH_SIZE, jiraProjectKey);

            if (batch != null && !batch.isEmpty()) {
                printData(batch);
                System.out.println("Inserting/updating data in collection " + collectionName + "...");
                upsertData(collectionName, pojoClass, batch, jiraProjectKey);
                System.out.println("Page " + page + " processed successfully.");
                page++;
            } else {
                System.out.println("No more data to fetch for collection " + collectionName + ".");
            }
        } while (batch != null && !batch.isEmpty());

        System.out.println("Updating scheduler info for collection " + collectionName + "...");
        updateSchedulerInfo(collectionName, jiraProjectKey);
        System.out.println("Scheduler info updated for collection " + collectionName + ".");
    }

    private <T> List<T> fetchDataBatch(String collectionName, Class<T> pojoClass, int page, int batchSize, String jiraProjectKey) {
        Query query = new Query()
                .with(PageRequest.of(page, batchSize))
                .addCriteria(Criteria.where("jiraProjectKey").is(jiraProjectKey));
        return sourceMongoTemplate.find(query, pojoClass, collectionName);
    }

    private <T> void printData(List<T> data) {
        if (data != null && !data.isEmpty()) {
            System.out.println("Printing " + data.size() + " documents:");
            data.forEach(item -> System.out.println(item.toString()));
        } else {
            System.out.println("No documents to print.");
        }
    }

    private <T> void upsertData(String collectionName, Class<T> pojoClass, List<T> data, String jiraProjectKey) {
        if (data != null && !data.isEmpty()) {
            for (T item : data) {
                try {
                    String idField = "_id";
                    String lastUpdatedField = "lastUpdated";

                    Object idValue = getFieldValue(item, idField);
                    Object lastUpdatedValue = getFieldValue(item, lastUpdatedField);

                    Date lastUpdatedDate = parseDate(lastUpdatedValue, DATE_FORMAT);

                    Query query = new Query(Criteria.where(idField).is(idValue).and("jiraProjectKey").is(jiraProjectKey));

                    T existingDocument = targetMongoTemplate.findOne(query, pojoClass, collectionName);

                    if (existingDocument != null) {
                        Object existingLastUpdatedValue = getFieldValue(existingDocument, lastUpdatedField);
                        Date existingLastUpdatedDate = parseDate(existingLastUpdatedValue, DATE_FORMAT);

                        if (lastUpdatedDate != null && (existingLastUpdatedDate == null || lastUpdatedDate.after(existingLastUpdatedDate))) {
                            Update update = new Update();
                            Map<String, Object> fields = getFieldValues(item);

                            fields.forEach((key, value) -> {
                                if (!key.equals(idField) && !key.equals(lastUpdatedField)) {
                                    update.set(key, value);
                                }
                            });

                            update.set(lastUpdatedField, DATE_FORMAT.format(lastUpdatedDate));

                            targetMongoTemplate.upsert(query, update, collectionName);
                            System.out.println("Document with ID " + idValue + " updated in collection " + collectionName);
                        } else {
                            System.out.println("Document with ID " + idValue + " is up-to-date in collection " + collectionName);
                        }
                    } else {
                        item = setLastUpdatedField(item, lastUpdatedField, lastUpdatedDate);
                        targetMongoTemplate.insert(item, collectionName);
                        System.out.println("Document with ID " + idValue + " inserted into collection " + collectionName);
                    }
                } catch (Exception e) {
                    System.err.println("Error processing document: " + e.getMessage());
                }
            }

            System.out.println("Successfully processed " + data.size() + " documents in collection " + collectionName);
        }
    }

    private Date parseDate(Object dateObject, SimpleDateFormat dateFormat) {
        if (dateObject instanceof Date) {
            return (Date) dateObject;
        } else if (dateObject instanceof String) {
            String dateString = (String) dateObject;
            if (dateString == null || dateString.trim().isEmpty()) {
                return null;
            }
            try {
                return dateFormat.parse(dateString);
            } catch (ParseException e) {
                System.err.println("Error parsing date: " + e.getMessage());
                return null;
            }
        }
        return null;
    }

    private Object getFieldValue(Object item, String fieldName) throws NoSuchFieldException, IllegalAccessException {
        Field field = item.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        return field.get(item);
    }

    private <T> Map<String, Object> getFieldValues(T item) {
        Map<String, Object> fieldValues = new HashMap<>();
        Field[] fields = item.getClass().getDeclaredFields();

        for (Field field : fields) {
            field.setAccessible(true);
            try {
                fieldValues.put(field.getName(), field.get(item));
            } catch (IllegalAccessException e) {
                System.err.println("Error accessing field: " + e.getMessage());
            }
        }

        return fieldValues;
    }

    private <T> T setLastUpdatedField(T item, String lastUpdatedField, Date lastUpdatedDate) {
        try {
            Field field = item.getClass().getDeclaredField(lastUpdatedField);
            field.setAccessible(true);
            field.set(item, DATE_FORMAT.format(lastUpdatedDate));
        } catch (Exception e) {
            System.err.println("Error setting lastUpdated field: " + e.getMessage());
        }
        return item;
    }

    private void updateSchedulerInfo(String collectionName, String jiraProjectKey) {
        Query query = new Query(Criteria.where("collectionName").is(collectionName).and("jiraProjectKey").is(jiraProjectKey));
        Update update = new Update()
                .set("lastRun", SCHEDULER_DATE_FORMAT.format(new Date()))
                .set("status", "Completed");

        targetMongoTemplate.upsert(query, update, SchedulerInfo.class, "SchedulerInfo");
    }
}
