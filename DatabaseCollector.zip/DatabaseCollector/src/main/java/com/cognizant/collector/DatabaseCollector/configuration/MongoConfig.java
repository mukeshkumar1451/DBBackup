package com.cognizant.collector.DatabaseCollector.configuration;

import com.mongodb.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;

@Configuration
public class MongoConfig {

    @Value("${spring.data.mongodb.source.uri}")
    private String sourceMongoUri;

    @Value("${spring.data.mongodb.target.uri}")
    private String targetMongoUri;

    @Bean
    @Primary
    public MongoTemplate sourceMongoTemplate() {
        return new MongoTemplate(new SimpleMongoClientDatabaseFactory(MongoClients.create(sourceMongoUri), "Testing"));
    }

    @Bean
    public MongoTemplate targetMongoTemplate() {
        return new MongoTemplate(new SimpleMongoClientDatabaseFactory(MongoClients.create(targetMongoUri), "Collection"));
    }
}
